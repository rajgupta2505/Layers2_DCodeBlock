document.addEventListener("DOMContentLoaded", function() {
  const form = document.querySelector('form');

  form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(form);
    const xhr = new XMLHttpRequest();

    xhr.open(form.method, form.action, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onload = function() {
      if (xhr.status === 200) {
        alert('Login successful'); // Or handle successful login
      } else {
        alert('Login failed'); // Or handle login failure
      }
    };

    xhr.send(JSON.stringify(Object.fromEntries(formData.entries())));
  });
});
